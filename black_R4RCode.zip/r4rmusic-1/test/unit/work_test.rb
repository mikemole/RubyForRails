require File.dirname(__FILE__) + '/../test_helper'

class WorkTest < Test::Unit::TestCase
  fixtures :works

  # Replace this with your real tests.
  def test_truth
    assert_kind_of Work, works(:first)
  end
end

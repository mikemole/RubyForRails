class Composer < ActiveRecord::Base
  has_many :works
end

module EditionHelper
end

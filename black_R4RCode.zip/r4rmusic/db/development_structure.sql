CREATE TABLE `composers` (
  `id` int(11) NOT NULL auto_increment,
  `first_name` varchar(30) default NULL,
  `middle_name` varchar(30) default NULL,
  `last_name` varchar(30) default NULL,
  `birth_year` int(4) default NULL,
  `death_year` int(4) default NULL,
  `country` char(2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `composers_compositions` (
  `composer_id` int(11) NOT NULL,
  `composition_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `compositions` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) default NULL,
  `year` int(4) default NULL,
  `kee` char(9) default NULL,
  `genres` varchar(120) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `compositions_instruments` (
  `composition_id` int(11) NOT NULL,
  `instrument_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL auto_increment,
  `first_name` varchar(30) default NULL,
  `last_name` varchar(30) default NULL,
  `nick` varchar(15) default NULL,
  `password` varchar(40) default NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `editions` (
  `id` int(11) NOT NULL auto_increment,
  `work_id` int(11) NOT NULL,
  `description` varchar(15) default NULL,
  `publisher_id` int(11) NOT NULL,
  `year` int(4) default NULL,
  `len` int(4) default NULL,
  `price` float default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `instruments` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(20) default NULL,
  `family` varchar(15) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `instruments_works` (
  `work_id` int(11) NOT NULL,
  `instrument_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `orders` (
  `id` int(11) NOT NULL auto_increment,
  `edition_id` int(11) default NULL,
  `customer_id` int(11) default NULL,
  `status` char(4) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `publishers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(60) default NULL,
  `city` varchar(30) default NULL,
  `country` varchar(30) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL auto_increment,
  `edition_id` int(11) default NULL,
  `customer_id` int(11) default NULL,
  `status` char(4) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `works` (
  `id` int(11) NOT NULL auto_increment,
  `composer_id` int(11) default NULL,
  `title` varchar(100) default NULL,
  `year` int(4) default NULL,
  `kee` char(9) default NULL,
  `opus` varchar(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


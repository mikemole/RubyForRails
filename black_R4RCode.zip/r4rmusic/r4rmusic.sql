USE r4rmusic_development;
DROP TABLE IF EXISTS works;
DROP TABLE IF EXISTS composers;
DROP TABLE IF EXISTS composers_works;
DROP TABLE IF EXISTS instruments_works;
DROP TABLE IF EXISTS publishers;
DROP TABLE IF EXISTS editions;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS instruments;
DROP TABLE IF EXISTS editions_works;

CREATE TABLE works (
  id INT(11) NOT NULL AUTO_INCREMENT,
  composer_id INT(11),
  title VARCHAR(100),
  year INT(4),
  kee CHAR(9),
  opus VARCHAR(20),
  PRIMARY KEY (id)
);

CREATE TABLE instruments (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(20),
  family VARCHAR(15),
  PRIMARY KEY (id)
);

CREATE TABLE instruments_works (
  instrument_id INT(11) NOT NULL,
  work_id INT(11) NOT NULL
);

CREATE TABLE editions_works (
  edition_id INT(11) NOT NULL,
  work_id INT(11) NOT NULL
);

CREATE TABLE composers (
  id INT(11) NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(30),
  middle_name VARCHAR(30),
  last_name VARCHAR(30),
  birth_year INT(4),
  death_year INT(4),
  country CHAR(2),
  PRIMARY KEY (id)
);

CREATE TABLE publishers (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(60),
  city VARCHAR(30),
  country CHAR(2),
  PRIMARY KEY (id)
);

CREATE TABLE customers (
  id INT(11) NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(30),
  last_name VARCHAR(30), 
  nick VARCHAR(15),
  password VARCHAR(40),
  email VARCHAR(50),
  PRIMARY KEY (id)
);

CREATE TABLE orders (
  id INT(11) NOT NULL AUTO_INCREMENT,
  edition_id INT(11),
  customer_id INT(11),
  created_at DATETIME,
  status CHAR(4),
  PRIMARY KEY (id)
);

CREATE TABLE editions (
  id INT(11) NOT NULL AUTO_INCREMENT,
  title VARCHAR(100),
  description VARCHAR(30),
  publisher_id INT(11) NOT NULL,
  year INT(4),
  price FLOAT,
  PRIMARY KEY  (id)
);

INSERT INTO customers VALUES (1,"Emma","Peel","mrspeel",
"73bebb3baaa272570e2a175a45d00a229c0823f7","epeel@nowhere");
INSERT INTO customers VALUES (2,"David","Black","dblack",
"73bebb3baaa272570e2a175a45d00a229c0823f7","epeel@nowhere");

INSERT INTO instruments VALUES (1,"violin","strings");
INSERT INTO instruments VALUES (2,"cello","strings");
INSERT INTO instruments VALUES (3,"piano","keyboard");
INSERT INTO instruments VALUES (4,"harpsichord","keyboard");
INSERT INTO instruments VALUES (5,"flute","woodwinds");
INSERT INTO instruments VALUES (6,"french horn","brass");
INSERT INTO instruments VALUES (7,"orchestra","orchestra");

INSERT INTO composers VALUES (1,"Ludwig", "van", "Beethoven",
1770, 1827, "DE");
INSERT INTO composers VALUES (2,"Johannes","", "Brahms",
1833, 1897, "DE");
INSERT INTO composers VALUES (3,"Charles-Camille", "","Saint-Saens",
1835, 1921, "FR");
INSERT INTO composers VALUES (4,"Johann","Sebastian","Bach",
1685, 1750, "DE");
INSERT INTO composers VALUES (5,"George","Frideric","Handel",
1685,1747,"DE");

INSERT INTO publishers VALUES (1,"RubyTunes, Inc.","New York", "US");
INSERT INTO publishers VALUES (2,"D.Black Music","Paris", "FR");
INSERT INTO publishers VALUES (3,"ActionMusic","Chicago", "US");

INSERT INTO instruments_works VALUES (1,2);
INSERT INTO instruments_works VALUES (1,3);
INSERT INTO instruments_works VALUES (2,1);
INSERT INTO instruments_works VALUES (2,2);
INSERT INTO instruments_works VALUES (2,3);
INSERT INTO instruments_works VALUES (3,7);
INSERT INTO instruments_works VALUES (4,2);
INSERT INTO instruments_works VALUES (5,2);
INSERT INTO instruments_works VALUES (6,2);
INSERT INTO instruments_works VALUES (7,2);
INSERT INTO instruments_works VALUES (8,2);
INSERT INTO instruments_works VALUES (9,2);
INSERT INTO instruments_works VALUES (10,7);
INSERT INTO instruments_works VALUES (11,7);
INSERT INTO instruments_works VALUES (11,2);


INSERT INTO works VALUES (1,2,"Sonata #2",1886,"F major", "99");
INSERT INTO works VALUES (2,1,"Trio #1",1795,"C minor", "1, no. 3");
INSERT INTO works VALUES (3,3,"Symphony #3",1886,"C minor", "78");
INSERT INTO works VALUES (4,4,"Suite #1",1720,"G major", "BWV1007");
INSERT INTO works VALUES (5,4,"Suite #2",1720,"D minor", "BWV1008");
INSERT INTO works VALUES (6,4,"Suite #3",1720,"C major", "BWV1009");
INSERT INTO works VALUES (7,4,"Suite #4",1720,"Eb major","BWV1010");
INSERT INTO works VALUES (8,4,"Suite #5",1720,"C minor","BWV1011" );
INSERT INTO works VALUES (9,4,"Suite #6",1720,"D major","BWV1012" );
INSERT INTO works VALUES (10,3,"Symphony #4",1897,"E minor", "97");
INSERT INTO works VALUES (11,3,"Concerto #1",1873,"A minor", "33");
INSERT INTO works VALUES (12,5,"Messiah",1742,NULL, NULL);

INSERT INTO editions VALUES(1,NULL,"2nd",1,1977,10.95);
INSERT INTO editions VALUES(2,NULL,"revised",3,1985,15.95);
INSERT INTO editions VALUES(3,NULL,"transposed",2,1985,15.95);
INSERT INTO editions VALUES(4,NULL,"(unknown)",1,1985,15.95);
INSERT INTO editions VALUES(5,NULL,"3rd",2,1985,15.95);
INSERT INTO editions VALUES(6,NULL,"Urtext",3,1985,15.95);
INSERT INTO editions VALUES(7,NULL,"facsimile",1,1985,15.95);
INSERT INTO editions VALUES(8,NULL,"Authorized",2,1985,15.95);
INSERT INTO editions VALUES(9,NULL,"facsimile",3,1985,15.95);
INSERT INTO editions VALUES(10,NULL,"3rd",1,1985,15.95);
INSERT INTO editions VALUES(11,NULL,"4th",2,1985,15.95);
INSERT INTO editions VALUES(12,NULL,"facsimile",1,1985,15.95);
INSERT INTO editions VALUES(13,NULL,"Urtext",2,1985,15.95);
INSERT INTO editions VALUES(14,"Bach Cello Suites","Peters",2,1941,15.95);

INSERT INTO editions_works VALUES(1,1);
INSERT INTO editions_works VALUES(2,1);
INSERT INTO editions_works VALUES(3,3);
INSERT INTO editions_works VALUES(4,11);
INSERT INTO editions_works VALUES(5,10);
INSERT INTO editions_works VALUES(6,10);
INSERT INTO editions_works VALUES(7,10);
INSERT INTO editions_works VALUES(8,10);
INSERT INTO editions_works VALUES(9,12);
INSERT INTO editions_works VALUES(10,11);
INSERT INTO editions_works VALUES(11,11);
INSERT INTO editions_works VALUES(12,12);
INSERT INTO editions_works VALUES(13,12);
INSERT INTO editions_works VALUES(14,4);
INSERT INTO editions_works VALUES(14,5);
INSERT INTO editions_works VALUES(14,6);
INSERT INTO editions_works VALUES(14,7);
INSERT INTO editions_works VALUES(14,8);
INSERT INTO editions_works VALUES(14,9);

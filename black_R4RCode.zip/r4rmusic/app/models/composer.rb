class Composer < ActiveRecord::Base
  has_many :works,
           :order => "title"

  def publishers
    works.editions.publishers.uniq
  end

  def whole_name
    "#{first_name} #{middle_name} #{last_name}"
  end

  def editions
    works.map {|work| work.editions }.flatten.uniq
  end

  def Composer.sales_rankings
    r = Hash.new(0)
    Work.sales_rankings.map do |work,sales|
      r[work.composer.id] += sales
    end
    r
  end
end

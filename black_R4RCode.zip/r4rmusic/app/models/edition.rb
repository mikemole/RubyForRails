class Edition < ActiveRecord::Base
  has_and_belongs_to_many :works
  has_many   :orders
  belongs_to :publisher


  def Edition.of_works(works)
    works.map {|work| work.editions }.flatten.uniq
  end

  def composers
    works.map {|work| work.composer }.uniq
  end


# The edition might have a title of its own.  If not,
# fall back on the title of the first (and perhaps only)
# work in the edition.

  def nice_title
    (title || works[0].nice_title) + 
    " (#{publisher.name}, #{year})"
  end
end

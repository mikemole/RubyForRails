# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  def two_dec(n)
    "%.2f" % n
  end

end


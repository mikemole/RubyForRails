# Filters added to this controller will be run for all controllers in the application.
# Likewise, all the methods added will be available for all controllers.
class ApplicationController < ActionController::Base
  layout("base")

  before_filter :get_customer

  def get_customer
    if @session['customer']
      @c = Customer.find(@session['customer'])
    end
  end


  private
  def report_error(message)
    @message = message
    render("main/error")
    return false
  end

end

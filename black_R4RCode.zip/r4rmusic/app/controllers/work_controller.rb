class WorkController < ApplicationController
  helper :edition, :composer
  def show
    @work = Work.find(params[:id])
  end
end

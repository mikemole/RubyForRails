require '../config/environment.rb'
ENV['RAILS_ENV'] = "development"
testees = [Composer,Customer,Edition,Work,Order,Publisher,Instrument]

testees.each do |testee|
  fh = File.open("/tmp/#{testee.name.downcase}.yml","w")
  testee.find(:all).each_with_index do |t,n|
    h = { "test_#{n}" => t.attributes }
    fh.puts h.to_yaml
  end
  fh.close
end

fh = File.open("/tmp/instruments_works.yml","w")
n = 0
Work.find(:all).each do |work|
  work.instruments.each do |instr|
    fh.puts <<EOM
association#{n+=1}:
  instrument_id: #{instr.id}
  work_id: #{work.id}
EOM
end
end

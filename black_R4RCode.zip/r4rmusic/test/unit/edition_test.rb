require File.dirname(__FILE__) + '/../test_helper'

class EditionTest < Test::Unit::TestCase
  fixtures :editions, :works, :editions_works

  def test_bach
    bach = editions(:test_13)
    assert_equal(bach.works.size, 6)
    assert_equal(bach.works[0].key, "G major")
  end

end

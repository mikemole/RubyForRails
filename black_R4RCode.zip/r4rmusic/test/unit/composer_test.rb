require File.dirname(__FILE__) + '/../test_helper'

class ComposerTest < Test::Unit::TestCase
  fixtures :composers

  def setup
    @beet = composers(:test_0)
  end

  def test_first_name
    assert_equal(@beet.first_name, "Ludwig")
  end

  def test_whole_name
    assert_equal(@beet.whole_name, "Ludwig van Beethoven")
  end
    
end

require File.dirname(__FILE__) + '/../test_helper'

class CustomerTest < Test::Unit::TestCase
  fixtures :customers

  # Replace this with your real tests.
  def test_first
    assert_equal(customers(:emma).last_name, "Peel")
  end
end

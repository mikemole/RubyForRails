require File.dirname(__FILE__) + '/../test_helper'

class InstrumentTest < Test::Unit::TestCase
  fixtures :instruments

  # Replace this with your real tests.
  def test_truth
    assert_kind_of Instrument, instruments(:first)
  end
end

require File.dirname(__FILE__) + '/../test_helper'

class WorkTest < Test::Unit::TestCase
  fixtures :works, :instruments, :instruments_works

  def test_nice_title
    w = works(:test_2)
    assert_equal(w.nice_title, "Symphony #3 in C minor, op. 78, for orchestra")
    w = works(:test_3)
    assert_equal(w.nice_title, "Suite #1 in G major, BWV1007, for cello")
  end

  def test_nice_instruments
    w = works(:test_0)
    assert_equal(w.nice_instruments, "cello and piano")
    w = works(:test_1)
    assert_equal(w.nice_instruments, "violin, cello, and piano")
  end

  def test_century
    assert_equal(works(:test_1).century, "18th century")
  end

  def test_period
    assert_equal(works(:test_2).period, "Romantic")
  end
end
